<html>
<head>
<title> 
website design
</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<header>
	<video autoplay loop class="video-background" muted plays-inline>
<source src="projectvideo1.mp4" type="video/mp4">
</video>
<div class="nav">
<img src="logo.png" class="logo">
<ul class="menu">
<li><a href="login.php">LOGIN</a></li>
</ul>
</div>
<div class="msg">
<br><br><br><br>
<a href="about.html" class="btn btn1">CONTACT</a>
<a href="comment.php" class="btn btn2">REVIEWS</a>
</div>
</header>
</form>

</body>
</html>
